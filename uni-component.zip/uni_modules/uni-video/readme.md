## uts插件开发文档
[UTS 语法](https://uniapp.dcloud.net.cn/tutorial/syntax-uts.html)
[UTS API插件](https://uniapp.dcloud.net.cn/plugin/uts-plugin.html)
[UTS 组件插件](https://uniapp.dcloud.net.cn/plugin/uts-component.html)
[Hello UTS](https://gitcode.net/dcloud/hello-uts)


## video-view
此插件为uni-app x项目中内置 video 组件的开源uts组件插件，为了避免与内置 video 组件冲突，开源uts组件插件注册为 video-view 组件。

**注意**  
- video-view组件不支持[uni.createVideoContext](https://uniapp.dcloud.net.cn/uni-app-x/api/create-video-context.html)

