## 1.0.0（2023-01-16）
实现android/ios平台 animation-view 组件，仅支持 nvue 页面

## 1.0.1（2023-10-23）
android平台适配 uni-app x 项目，支持 uvue 页面，需使用 HBuilderX3.94+ 版本
